const root = document;
const menu = document.querySelector('.menu-toggle');
const nav = document.querySelector('.nav');
menu?.addEventListener('click', () => {
  const open = nav.classList.toggle('open');
  menu.setAttribute('aria-expanded', String(open));
});
nav?.querySelectorAll('a').forEach(a => a.addEventListener('click', () => {
  nav.classList.remove('open');
  menu?.setAttribute('aria-expanded','false');
}));

const revealObserver = new IntersectionObserver(entries => {
  entries.forEach(entry => {
    if (!entry.isIntersecting) return;
    entry.target.classList.add('visible');
    entry.target.querySelectorAll?.('[data-progress]').forEach(bar => {
      const value = Math.max(0, Math.min(100, Number(bar.dataset.progress) || 0));
      bar.style.width = value + '%';
    });
    revealObserver.unobserve(entry.target);
  });
}, {threshold:.12});
document.querySelectorAll('.reveal').forEach(el => revealObserver.observe(el));

const bars = document.querySelectorAll('.progress-row');
const barObserver = new IntersectionObserver(entries => {
  entries.forEach(entry => {
    if (!entry.isIntersecting) return;
    entry.target.querySelectorAll('[data-progress]').forEach(bar => {
      const value = Math.max(0, Math.min(100, Number(bar.dataset.progress) || 0));
      bar.style.width = value + '%';
    });
    barObserver.unobserve(entry.target);
  });
},{threshold:.35});
bars.forEach(el=>barObserver.observe(el));

const glow = document.querySelector('.cursor-glow');
if (glow && window.matchMedia('(pointer:fine)').matches) {
  window.addEventListener('pointermove', e => {
    glow.style.left = e.clientX + 'px';
    glow.style.top = e.clientY + 'px';
  }, {passive:true});
}

const form = document.getElementById('contactForm');
const status = document.getElementById('formStatus');
form?.addEventListener('submit', e => {
  e.preventDefault();
  const data = new FormData(form);
  const name = String(data.get('name') || '').trim();
  const email = String(data.get('email') || '').trim();
  const purpose = String(data.get('purpose') || '').trim();
  const message = String(data.get('message') || '').trim();
  if (!name || !email || !purpose || !message) {
    status.textContent = 'Please complete all fields.';
    return;
  }
  const subject = encodeURIComponent(`${purpose} — Website inquiry from ${name}`);
  const body = encodeURIComponent(`Name: ${name}\nEmail: ${email}\nPurpose: ${purpose}\n\n${message}`);
  window.location.href = `mailto:202602087@g.seoil.av.kr?subject=${subject}&body=${body}`;
  status.textContent = 'Opening your email app…';
});
