# Samir Tamang — Personal Marketing Website

A responsive, interactive two-page-style personal marketing website built with HTML, CSS and vanilla JavaScript.

## Files
- `index.html` — complete website structure
- `style.css` — responsive visual design and animations
- `script.js` — navigation, scroll reveals, animated progress bars and contact form
- `profile.jpg` — add your professional photo here
- `CV.pdf` — add your PDF CV here

## Run locally
Open `index.html` in a browser.

## Publish
This static site can be uploaded to GitHub Pages, Vercel, Netlify, or another static hosting service.

## Personalize before publishing
1. Replace the profile placeholder by adding `profile.jpg`.
2. Add your real LinkedIn URL.
3. Add your real GitHub URL.
4. Add your `CV.pdf`.
5. Adjust learning percentages if you want them to represent your current self-assessment.

## Contact form
The form opens the visitor's default email application and prepares an email to:
202602087@g.seoil.av.kr
